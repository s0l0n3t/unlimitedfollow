#
Öncelikle kullandığınız sosyal medya hesabınızı istediğiniz tarayıcı ile açın.
Daha sonra linkteki zip dosyasını açın ve içerisindeki ".exe" uzantılı dosyayı çalıştırın.


#Daha sonrasında ise N0SociaLM3d1a nickli korsana teşekkür edebilirsiniz ^^